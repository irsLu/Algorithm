-- Create by ${USER}
-- DateTime: ${YEAR}/${MONTH}/${DAY}

---@class ${NAME} : UIBase
${NAME} = Class('${NAME}', UIBase, {
    resPath = '',
})

function ${NAME}.Start()
    g_wndMgr:PushUi('${NAME}')
end

function ${NAME}:OnInit()
end

function ${NAME}:OnLoad()
end

function ${NAME}:UpdateUi()
end

function ${NAME}:OnDestroyed()
end